// @/data/categories.ts
import { useEffect, useState } from "react";
import axios from "axios";
import { Category } from "@/types"; // Đảm bảo đường dẫn đúng

export const useCategories = (accessToken: string | null) => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        if (!accessToken) return;
        const res = await axios.get("http://127.0.0.1:8000/api/categories/", {
          headers: {
            accept: "application/json",
            Authorization: `Bearer ${accessToken}`,
          },
        });
        setCategories(res.data.results);
      } catch (err) {
        setError("Không thể tải danh mục");
        console.error("Lỗi khi tải danh mục:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchCategories();
  }, [accessToken]);

  return { categories, loading, error };
};
