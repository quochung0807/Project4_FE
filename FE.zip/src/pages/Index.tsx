
// This page is replaced by the new Home page
export { default } from './Home';
